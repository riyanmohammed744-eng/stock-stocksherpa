/* StockSherpa – KiranaKeeper | Vanilla JS, data persisted in LocalStorage */
const $ = (s, e = document) => e.querySelector(s);
const K = 'kk_v1', CATS = ['Staples', 'Dairy', 'Snacks', 'Beverages', 'Spices', 'Personal Care', 'Household'];
const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = t => new Date(t).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' });

/* ---------- Sample data (loaded on first visit / reset) ---------- */
function seed() {
  const day = n => +n ? new Date(Date.now() + n * 864e5).toISOString().slice(0, 10) : '';
  // name,cost,price,qty,min,expiry-in-days (0 = none)
  const G = {
    Staples: [1, 'Basmati Rice 1kg,92,110,24,8,0;Wheat Atta 5kg,205,235,6,5,0;Toor Dal 1kg,140,165,18,6,0;Moong Dal 1kg,118,140,12,6,0;Chana Dal 1kg,82,98,3,6,0;Sugar 1kg,41,48,30,10,0;Salt 1kg,20,24,40,10,0;Cooking Oil 1L,128,148,0,6,0;Mustard Oil 1L,150,172,10,5,0;Besan 500g,45,55,9,4,0;Poha 500g,38,48,14,5,0;Rajma 500g,70,85,8,4,0;Suji 500g,28,36,11,5,0;Jaggery 1kg,52,65,7,4,0;Urad Dal 1kg,125,150,2,5,0;Sona Masoori Rice 5kg,290,335,9,4,0;Peanuts 500g,62,78,9,4,0;Vermicelli 500g,28,36,10,4,0'],
    Dairy: [2, 'Milk 500ml,26,30,40,15,2;Curd 400g,28,35,12,8,5;Butter 100g,52,60,15,6,25;Paneer 200g,70,85,5,5,6;Cheese Slices 200g,105,125,8,4,28;Ghee 500ml,285,330,10,4,180;Bread,32,40,10,6,3'],
    Snacks: [2, 'Maggi Noodles 70g,12,14,60,20,120;Parle-G 200g,16,20,48,15,150;Good Day Biscuits,25,30,22,10,120;Marie Gold,22,28,18,8,140;Bourbon Biscuits,22,30,0,8,130;Lays Chips,16,20,30,10,70;Kurkure,16,20,25,10,60;Haldiram Bhujia 200g,48,60,14,6,20'],
    Beverages: [2, 'Tea Powder 250g,98,120,16,6,300;Coffee 100g,150,180,9,4,365;Horlicks 500g,235,270,6,3,300;Frooti 200ml,9,10,50,15,160;Pepsi 750ml,34,40,20,8,100;Bisleri Water 1L,14,20,50,15,300'],
    Spices: [1, 'Turmeric Powder 200g,38,48,15,6,300;Red Chilli Powder 200g,52,65,12,6,300;Coriander Powder 200g,34,44,10,5,300;Garam Masala 100g,62,80,7,4,300;Cumin Seeds 100g,45,58,2,5,300;Mustard Seeds 100g,15,20,12,5,300;Black Pepper 50g,48,62,8,3,300;Hing 50g,40,52,6,3,300'],
    'Personal Care': [3, 'Soap,30,38,40,12,700;Shampoo 180ml,110,135,10,5,600;Toothpaste 150g,72,90,18,6,600;Toothbrush,18,25,22,8,0;Hair Oil 200ml,78,95,9,4,600;Face Wash,95,120,6,3,600'],
    Household: [3, 'Detergent Powder 1kg,98,120,14,6,500;Dishwashing Liquid 500ml,88,110,11,5,500;Floor Cleaner 1L,120,150,6,3,500;Toilet Cleaner 500ml,78,98,3,4,500;Matchbox Pack,8,10,60,20,0;Agarbatti,18,25,25,10,0;Garbage Bags,45,60,10,4,0;Scrub Pad,12,15,30,10,0']
  };
  let id = 0; const products = [];
  for (const c in G) G[c][1].split(';').forEach(r => {
    const [name, cost, price, qty, min, e] = r.split(','); id++;
    products.push({ id, name, sku: '89012' + (10000 + id * 7), cat: c, cost: +cost, price: +price, qty: +qty, min: +min, exp: day(e), sup: G[c][0] });
  });
  // a few past sales so "best sellers" has data
  const moves = products.slice(0, 14).map((p, i) => ({ t: Date.now() - i * 36e5, pid: p.id, name: p.name, d: -(3 + i % 5 * 2), q: p.qty, why: 'Sale' }));
  return {
    products, moves, orders: [], settings: { shop: 'Sharma Kirana Store', cover: 2 },
    suppliers: [
      { id: 1, name: 'Sharma Wholesale Mart', contact: 'Ramesh Sharma', phone: '9876543210', wa: '919876543210', cats: 'Staples, Spices', addr: 'Gandhi Road, Medchal, Telangana' },
      { id: 2, name: 'Gupta Distributors', contact: 'Anil Gupta', phone: '9845012345', wa: '919845012345', cats: 'Dairy, Snacks, Beverages', addr: 'Market Yard, Secunderabad' },
      { id: 3, name: 'Metro Home Care Supplies', contact: 'Priya Reddy', phone: '9966778899', wa: '919966778899', cats: 'Personal Care, Household', addr: 'Kukatpally, Hyderabad' }]
  };
}
let S = JSON.parse(localStorage.getItem(K) || 'null') || seed();
const save = () => localStorage.setItem(K, JSON.stringify(S));
save();

/* ---------- Helpers ---------- */
const status = p => p.qty <= 0 ? 'out' : p.qty <= p.min ? 'low' : 'ok';
const badge = p => ({ ok: '<span class="b ok">In Stock</span>', low: '<span class="b low">Low Stock</span>', out: '<span class="b out">Out of Stock</span>' })[status(p)];
const days = p => p.exp ? Math.ceil((new Date(p.exp + 'T00:00:00') - new Date().setHours(0, 0, 0, 0)) / 864e5) : null;
const supName = p => (S.suppliers.find(s => s.id == p.sup) || {}).name || 'No supplier';
const lowList = () => S.products.filter(p => status(p) !== 'ok');
const suggest = p => Math.max(p.min * S.settings.cover - p.qty, p.min); // target = min × cover, at least one threshold's worth
const totals = () => {
  const inv = S.products.reduce((a, p) => a + p.cost * p.qty, 0), rev = S.products.reduce((a, p) => a + p.price * p.qty, 0);
  return { inv, rev, profit: rev - inv, low: S.products.filter(p => status(p) == 'low').length, out: S.products.filter(p => status(p) == 'out').length };
};
function toast(m, err) { const t = document.createElement('div'); t.className = 't' + (err ? ' e' : ''); t.textContent = m; $('#toasts').append(t); setTimeout(() => t.remove(), 2800); }
const stat = (l, v, c = '') => `<div class="card stat ${c}"><small>${l}</small><b>${v}</b></div>`;

/* Change stock by delta, never below zero, and log it in the ledger */
function adjust(id, d, why) {
  const p = S.products.find(x => x.id == id), old = p.qty;
  p.qty = Math.max(0, old + d);
  if (p.qty == old) return toast('Stock cannot go below zero', true);
  S.moves.unshift({ t: Date.now(), pid: p.id, name: p.name, d: p.qty - old, q: p.qty, why: why || (d < 0 ? 'Sale' : 'Restock') });
  save(); render();
  if (status(p) != 'ok' && old > p.min) toast(p.name + ' is now ' + (p.qty ? 'low on stock' : 'out of stock'), true);
}

/* Generic modal form builder with validation callback */
function modal(title, fields, v, ok) {
  const d = $('#dlg');
  d.innerHTML = `<form><h3>${title}</h3><div class="fg">${fields.map(([k, l, t, o]) => `<label>${l}${t == 'select' ? `<select name="${k}">${o.map(x => `<option value="${esc(x[0])}" ${x[0] == v[k] ? 'selected' : ''}>${esc(x[1])}</option>`).join('')}</select>` : `<input name="${k}" type="${t}" value="${esc(v[k])}" ${t == 'number' ? 'min="0" step="any"' : ''}>`}</label>`).join('')}</div><p class="err"></p><div class="acts"><button type="button" id="x">Cancel</button><button class="pri">Save</button></div></form>`;
  $('#x').onclick = () => d.close();
  d.querySelector('form').onsubmit = e => {
    e.preventDefault();
    const m = ok(Object.fromEntries(new FormData(e.target)));
    m ? $('.err', d).textContent = m : d.close();
  };
  d.showModal();
}

function editProduct(id) {
  const p = S.products.find(x => x.id == id) || { cat: CATS[0], sup: S.suppliers[0]?.id, min: 5 };
  modal(p.id ? 'Edit product' : 'Add product', [['name', 'Product name', 'text'], ['sku', 'SKU / Barcode', 'text'], ['cat', 'Category', 'select', CATS.map(c => [c, c])], ['cost', 'Cost price (₹)', 'number'], ['price', 'Selling price (₹)', 'number'], ['qty', 'Current quantity', 'number'], ['min', 'Minimum stock', 'number'], ['exp', 'Expiry date', 'date'], ['sup', 'Supplier', 'select', S.suppliers.map(s => [s.id, s.name])]], p, d => {
    if (!d.name.trim() || !d.sku.trim()) return 'Name and SKU are required.';
    if (['cost', 'price', 'qty', 'min'].some(k => d[k] === '' || +d[k] < 0)) return 'Enter valid, non-negative numbers.';
    if (S.products.some(x => x.sku == d.sku.trim() && x.id != p.id)) return 'This SKU already exists.';
    Object.assign(p, { name: d.name.trim(), sku: d.sku.trim(), cat: d.cat, cost: +d.cost, price: +d.price, qty: Math.floor(+d.qty), min: Math.floor(+d.min), exp: d.exp, sup: +d.sup });
    if (!p.id) { p.id = Date.now(); S.products.push(p); }
    save(); render(); toast('Product saved');
  });
}
function editSupplier(id) {
  const s = S.suppliers.find(x => x.id == id) || {};
  modal(s.id ? 'Edit supplier' : 'Add supplier', [['name', 'Supplier name', 'text'], ['contact', 'Contact person', 'text'], ['phone', 'Phone number', 'tel'], ['wa', 'WhatsApp (with country code)', 'tel'], ['cats', 'Product categories', 'text'], ['addr', 'Address', 'text']], s, d => {
    if (!d.name.trim()) return 'Supplier name is required.';
    if (d.wa && !/^\d{10,13}$/.test(d.wa.replace(/\D/g, ''))) return 'WhatsApp number must have 10–13 digits.';
    Object.assign(s, d);
    if (!s.id) { s.id = Date.now(); S.suppliers.push(s); }
    save(); render(); toast('Supplier saved');
  });
}

/* ---------- Product card ---------- */
const pc = (p, hit) => {
  const dl = days(p);
  return `<div class="pc ${hit ? 'hit' : ''}"><div class="ph"><b>${esc(p.name)}</b>${badge(p)}</div><small>${esc(p.sku)} | ${esc(p.cat)}</small><small>Cost ${inr(p.cost)} | Sell ${inr(p.price)} | Min ${p.min}</small>
  <div class="qty"><span class="n">${p.qty}</span><div class="adj">${[-10, -1, 1, 10].map(d => `<button data-adj="${p.id}" data-d="${d}">${d > 0 ? '+' : ''}${d}</button>`).join('')}</div></div>
  <div class="ex"><span>${esc(supName(p))}</span>${dl !== null && dl <= 30 ? `<span class="b exp">${dl < 0 ? 'Expired' : dl + 'd left'}</span>` : ''}</div>
  <div class="acts"><button data-edit="${p.id}">Edit</button><button class="del" data-del="${p.id}">Delete</button></div></div>`;
};

/* ---------- Pages ---------- */
let cur = 'overview', F = { q: '', cat: '', sort: '' }, EX = 30, BQ = '', R = {}; // UI state: filters, expiry period, barcode query, edited reorder qty
const CH = {};
const chart = (id, cfg) => { if (!window.Chart || !document.getElementById(id)) return; CH[id]?.destroy(); CH[id] = new Chart(document.getElementById(id), cfg); };
const expiring = n => S.products.filter(p => days(p) !== null && days(p) <= n).sort((a, b) => days(a) - days(b));
const dlTxt = p => { const d = days(p); return d < 0 ? 'Expired ' + -d + 'd ago' : d == 0 ? 'Today' : d + ' days'; };
const moveRows = (n) => S.moves.slice(0, n).map(m => `<tr><td>${fmt(m.t)}</td><td>${esc(m.name)}</td><td style="color:${m.d < 0 ? 'var(--red)' : 'var(--emd)'}">${m.d > 0 ? '+' : ''}${m.d}</td><td>${m.q}</td><td>${m.why}</td></tr>`).join('');
const moveTbl = n => `<div class="tw"><table><tr><th>Time</th><th>Product</th><th>Change</th><th>Balance</th><th>Type</th></tr>${moveRows(n)}</table></div>`;

const pages = {
  overview: {
    t: 'Overview',
    r() {
      const t = totals(), low = lowList(), ex = expiring(15);
      return `${low.length ? `<div class="banner">⚠ ${t.low} item(s) low on stock and ${t.out} out of stock. Open the Reorder Assistant to restock.</div>` : ''}${ex.length ? `<div class="banner o">⏳ ${ex.length} product(s) expire within 15 days.</div>` : ''}
      <div class="cards">${stat('Total Products', S.products.length)}${stat('Inventory Value', inr(t.inv))}${stat('Potential Retail Revenue', inr(t.rev))}${stat('Expected Gross Profit', inr(t.profit), 'g')}${stat('Low Stock Items', t.low, 'o')}${stat('Out of Stock', t.out, 'r')}</div>
      <p class="note">Values are inventory-based estimates, not realised profit.</p>
      <div class="two"><div class="card"><h3>Inventory statistics</h3><canvas id="c1"></canvas></div><div class="card"><h3>Category-wise stock distribution</h3><canvas id="c2"></canvas></div></div>
      <div class="two"><div class="card"><h3>Low-stock alerts</h3>${low.slice(0, 8).map(p => `<div class="li"><span>${esc(p.name)}</span>${badge(p)} <b>${p.qty}/${p.min}</b></div>`).join('') || '<p class="mu">All stock levels are healthy.</p>'}</div>
      <div class="card"><h3>Expiring products</h3>${ex.slice(0, 8).map(p => `<div class="li"><span>${esc(p.name)}</span><span class="b exp">${dlTxt(p)}</span></div>`).join('') || '<p class="mu">Nothing expiring soon.</p>'}</div></div>
      <div class="card"><h3>Recent stock activity</h3>${moveTbl(8)}</div>`;
    },
    a() {
      const t = totals(), ok = S.products.length - t.low - t.out;
      chart('c1', { type: 'bar', data: { labels: ['Healthy', 'Low', 'Out', 'Expiring ≤15d'], datasets: [{ data: [ok, t.low, t.out, expiring(15).length], backgroundColor: ['#10b981', '#ef4444', '#991b1b', '#f97316'], borderRadius: 8 }] }, options: { plugins: { legend: { display: false } } } });
      chart('c2', { type: 'doughnut', data: { labels: CATS, datasets: [{ data: CATS.map(c => S.products.filter(p => p.cat == c).reduce((a, p) => a + p.qty, 0)), backgroundColor: ['#10b981', '#0f1b33', '#f97316', '#38bdf8', '#ef4444', '#a78bfa', '#facc15'] }] }, options: { plugins: { legend: { position: 'right' } } } });
    }
  },
  products: {
    t: 'Products',
    r() {
      return `<div class="bar"><input id="q" placeholder="Search by name, SKU or category" value="${esc(F.q)}"><select id="fc"><option value="">All categories</option>${CATS.map(c => `<option ${F.cat == c ? 'selected' : ''}>${c}</option>`).join('')}</select><select id="fs"><option value="">Sort: Name</option><option value="asc" ${F.sort == 'asc' ? 'selected' : ''}>Stock: low to high</option><option value="desc" ${F.sort == 'desc' ? 'selected' : ''}>Stock: high to low</option></select><button class="pri" data-act="addp">+ Add product</button></div><div class="grid" id="list">${this.list()}</div>`;
    },
    list() {
      const q = F.q.toLowerCase();
      let l = S.products.filter(p => (!F.cat || p.cat == F.cat) && (!q || [p.name, p.sku, p.cat].some(x => x.toLowerCase().includes(q))));
      l = F.sort ? l.sort((a, b) => F.sort == 'asc' ? a.qty - b.qty : b.qty - a.qty) : l.sort((a, b) => a.name.localeCompare(b.name));
      return l.map(p => pc(p)).join('') || '<p class="mu">No products match. Try another search.</p>';
    }
  },
  inventory: {
    t: 'Inventory & Barcode Search',
    r() {
      return `<div class="bar"><input id="bq" placeholder="Type or scan a barcode / SKU, then adjust stock" value="${esc(BQ)}" autofocus></div><div class="grid" id="blist">${this.list()}</div><div class="card" style="margin-top:18px"><h3>Stock movement ledger</h3>${moveTbl(25)}</div>`;
    },
    list() {
      const q = BQ.trim().toLowerCase();
      if (!q) return '<p class="mu">Enter a SKU or barcode to find a product. USB barcode scanners work like a keyboard here.</p>';
      const l = S.products.filter(p => p.sku.toLowerCase().includes(q) || p.name.toLowerCase().includes(q));
      return l.map(p => pc(p, p.sku.toLowerCase() == q)).join('') || '<p class="mu">No product with that barcode.</p>';
    }
  },
  reorder: {
    t: 'Reorder Assistant',
    r() {
      const low = lowList();
      if (!low.length) return '<div class="card"><h3>Nothing to reorder</h3><p class="mu">Every product is above its minimum stock threshold.</p></div>';
      const groups = {}; low.forEach(p => (groups[p.sup] = groups[p.sup] || []).push(p));
      return Object.keys(groups).map(sid => {
        const l = groups[sid], rq = p => R[p.id] ?? suggest(p), tot = l.reduce((a, p) => a + rq(p) * p.cost, 0), s = S.suppliers.find(x => x.id == sid);
        return `<div class="card sec"><h3><span>${esc(s ? s.name : 'No supplier assigned')}</span><button class="pri" data-wa="${sid}">Generate WhatsApp Order</button></h3><div class="tw"><table><tr><th>Product</th><th>Current</th><th>Min</th><th>Order qty</th><th>Est. cost</th></tr>${l.map(p => `<tr><td>${esc(p.name)} ${badge(p)}</td><td>${p.qty}</td><td>${p.min}</td><td><input type="number" min="1" data-rq="${p.id}" value="${rq(p)}"></td><td>${inr(rq(p) * p.cost)}</td></tr>`).join('')}</table></div><p style="margin-top:10px"><b>Estimated total: ${inr(tot)}</b></p></div>`;
      }).join('') + '<p class="note">WhatsApp opens with the message pre-filled. Review it there; nothing is sent automatically.</p>';
    }
  },
  expiry: {
    t: 'Expiry Tracker',
    r() {
      const l = expiring(EX);
      return `<div class="bar"><select id="ep">${[[7, 'Within 7 days'], [15, 'Within 15 days'], [30, 'Within 30 days'], [9999, 'All with expiry date']].map(([v, n]) => `<option value="${v}" ${EX == v ? 'selected' : ''}>${n}</option>`).join('')}</select></div><div class="card tw"><table><tr><th>Product</th><th>Expiry</th><th>Remaining</th><th>Qty</th><th>Stock at risk</th></tr>${l.map(p => `<tr><td>${esc(p.name)}</td><td>${p.exp}</td><td><span class="b ${days(p) <= 7 ? 'low' : 'exp'}">${dlTxt(p)}</span></td><td>${p.qty}</td><td>${inr(p.qty * p.cost)}</td></tr>`).join('') || '<tr><td>No products in this period.</td></tr>'}</table></div>`;
    }
  },
  suppliers: {
    t: 'Suppliers',
    r() {
      return `<div class="bar"><button class="pri" data-act="adds">+ Add supplier</button></div><div class="grid">${S.suppliers.map(s => `<div class="pc"><b>${esc(s.name)}</b><small>${esc(s.contact)} | ${esc(s.phone)}</small><small>WhatsApp: ${esc(s.wa)}</small><small>${esc(s.cats)}</small><small>${esc(s.addr)}</small><small>${S.products.filter(p => p.sup == s.id).length} products | ${S.products.filter(p => p.sup == s.id && status(p) != 'ok').length} need reorder</small><div class="acts"><button data-wa="${s.id}">Order</button><button data-es="${s.id}">Edit</button><button class="del" data-ds="${s.id}">Delete</button></div></div>`).join('')}</div>`;
    }
  },
  reports: {
    t: 'Reports',
    r() {
      const t = totals();
      return `<div class="cards">${stat('Total inventory value', inr(t.inv))}${stat('Potential retail revenue', inr(t.rev))}${stat('Expected gross profit', inr(t.profit), 'g')}</div><p class="note">Estimates based on current stock (cost × qty, price × qty). They are not realised profit.</p>
      <div class="two"><div class="card"><h3>Inventory value by category</h3><canvas id="r1"></canvas></div><div class="card"><h3>Best-selling products (recorded sales)</h3><canvas id="r2"></canvas></div></div>
      <div class="card sec"><h3>Low-stock report</h3><div class="tw"><table><tr><th>Product</th><th>Qty</th><th>Min</th><th>Suggested order</th><th>Supplier</th></tr>${lowList().map(p => `<tr><td>${esc(p.name)}</td><td>${p.qty}</td><td>${p.min}</td><td>${suggest(p)}</td><td>${esc(supName(p))}</td></tr>`).join('') || '<tr><td>None</td></tr>'}</table></div></div>
      <div class="card"><h3>Stock movement history</h3>${moveTbl(30)}</div>`;
    },
    a() {
      chart('r1', { type: 'bar', data: { labels: CATS, datasets: [{ label: 'Cost value (₹)', data: CATS.map(c => S.products.filter(p => p.cat == c).reduce((a, p) => a + p.cost * p.qty, 0)), backgroundColor: '#10b981', borderRadius: 6 }] } });
      const s = {}; S.moves.filter(m => m.why == 'Sale').forEach(m => s[m.name] = (s[m.name] || 0) - m.d);
      const top = Object.entries(s).sort((a, b) => b[1] - a[1]).slice(0, 8);
      chart('r2', { type: 'bar', data: { labels: top.map(x => x[0]), datasets: [{ label: 'Units sold', data: top.map(x => x[1]), backgroundColor: '#0f1b33', borderRadius: 6 }] }, options: { indexAxis: 'y' } });
    }
  },
  settings: {
    t: 'Settings',
    r() {
      return `<div class="card" style="max-width:520px"><div class="fg"><label>Shop name<input id="sn" value="${esc(S.settings.shop)}"></label><label>Reorder cover (× minimum stock)<input id="sc" type="number" min="1" step="0.5" value="${S.settings.cover}"></label></div><p class="note">Suggested reorder = minimum × cover − current stock.</p><div class="acts" style="justify-content:flex-start"><button class="pri" data-act="saveset">Save settings</button><button class="del" data-act="reset">Reset demo data</button></div></div>`;
    }
  }
};

function render() {
  const pg = pages[cur];
  $('#app').innerHTML = pg.r(); $('#title').textContent = pg.t; $('#shop').textContent = S.settings.shop;
  document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('on', a.dataset.p == cur));
  pg.a && pg.a(); window.lucide && lucide.createIcons();
}
function go(p) { cur = p; document.body.classList.remove('nav'); render(); scrollTo(0, 0); }

/* Build a formatted purchase order and open WhatsApp (user reviews & sends manually) */
function sendOrder(sid) {
  const s = S.suppliers.find(x => x.id == sid), items = lowList().filter(p => p.sup == sid);
  if (!items.length) return toast('No low-stock items for this supplier', true);
  const lines = items.map((p, i) => { const q = R[p.id] ?? suggest(p); return `${i + 1}. ${p.name} x ${q} (approx ${inr(q * p.cost)})`; });
  const total = items.reduce((a, p) => a + (R[p.id] ?? suggest(p)) * p.cost, 0);
  const msg = `*Purchase Order - ${S.settings.shop}*\nTo: ${s ? s.name : 'Supplier'}\nDate: ${new Date().toLocaleDateString('en-IN')}\n\n${lines.join('\n')}\n\n*Estimated total: ${inr(total)}*\n\nPlease confirm availability and delivery time. Thank you.`;
  S.orders.push({ t: Date.now(), sup: sid, total, items: items.length }); save();
  let num = ((s && s.wa) || '').replace(/\D/g, ''); if (num.length == 10) num = '91' + num;
  window.open(`https://wa.me/${num}?text=${encodeURIComponent(msg)}`, '_blank');
  toast('WhatsApp opened. Review the order and press send.');
}

/* ---------- Events (delegated) ---------- */
document.addEventListener('click', e => {
  const t = e.target.closest('button,a,#menu,#scrim'); if (!t) return;
  const d = t.dataset;
  if (t.id == 'menu') document.body.classList.toggle('nav');
  else if (t.id == 'scrim') document.body.classList.remove('nav');
  else if (d.p) go(d.p);
  else if (d.adj) adjust(d.adj, +d.d);
  else if (d.edit) editProduct(d.edit);
  else if (d.del) { const p = S.products.find(x => x.id == d.del); if (confirm(`Delete "${p.name}"? This cannot be undone.`)) { S.products = S.products.filter(x => x != p); save(); render(); toast('Product deleted'); } }
  else if (d.es) editSupplier(d.es);
  else if (d.ds) { const s = S.suppliers.find(x => x.id == d.ds); if (confirm(`Delete supplier "${s.name}"? Their products will have no supplier.`)) { S.suppliers = S.suppliers.filter(x => x != s); S.products.forEach(p => p.sup == s.id && (p.sup = 0)); save(); render(); toast('Supplier deleted'); } }
  else if (d.wa) sendOrder(d.wa);
  else if (d.act == 'addp') editProduct();
  else if (d.act == 'adds') editSupplier();
  else if (d.act == 'saveset') { const c = +$('#sc').value; if (!$('#sn').value.trim() || !(c >= 1)) return toast('Enter a shop name and cover of at least 1', true); S.settings = { shop: $('#sn').value.trim(), cover: c }; save(); render(); toast('Settings saved'); }
  else if (d.act == 'reset' && confirm('Reset everything to the demo data? Your changes will be lost.')) { S = seed(); R = {}; save(); render(); toast('Demo data restored'); }
});
document.addEventListener('input', e => {
  const i = e.target.id;
  if (i == 'q') { F.q = e.target.value; $('#list').innerHTML = pages.products.list(); }
  else if (i == 'bq') { BQ = e.target.value; $('#blist').innerHTML = pages.inventory.list(); }
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.id == 'fc') { F.cat = t.value; render(); }
  else if (t.id == 'fs') { F.sort = t.value; render(); }
  else if (t.id == 'ep') { EX = +t.value; render(); }
  else if (t.dataset.rq) { R[t.dataset.rq] = Math.max(1, Math.floor(+t.value) || 1); render(); }
});
render();
